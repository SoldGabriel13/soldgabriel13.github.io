// Phoneme-string parser and schedule compiler

import { banks, resolveBank } from './banks/index.js';
import { MAX_FORMANTS, MAX_ANTIFORMANTS } from './synth-core.js';

const PAUSE_MS = { ',': 100, ';': 200, '.': 300 };

// Convert note names like "C4", "C#5", "Db3", "A-1" to Hz.
const NOTE_SEMITONES = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
function noteToHz(name) {
  const m = name.match(/^([A-G])([b#]?)(-?\d+)$/);
  if (!m) return null;
  const [, letter, accidental, octaveStr] = m;
  let semi = NOTE_SEMITONES[letter];
  if (accidental === '#') semi += 1;
  else if (accidental === 'b') semi -= 1;
  const octave = parseInt(octaveStr, 10);
  const midi = (octave + 1) * 12 + semi;
  return 440 * Math.pow(2, (midi - 69) / 12);
}

const DEFAULTS = Object.freeze({
  baseF0: 120,
  rate: 110,                  // ms per phoneme
  stressDurationFactor: 1.5,
  stressF0Lift: 8,            // Hz
  stopBurstMs: 25,
  defaultTransitionMs: 35,
  sentenceFinalHoldMs: 0,
  fadeOutMs: 100,
  trailOffMs: 150,
});

const HOMOGLYPH_MAP = {
  // Greek uppercase that look like Latin uppercase
  'Α':'A', 'Β':'B', 'Ε':'E', 'Η':'H', 'Ι':'I', 'Κ':'K',
  'Μ':'M', 'Ν':'N', 'Ο':'O', 'Ρ':'P', 'Τ':'T', 'Υ':'Y', 'Ζ':'Z',
  // Cyrillic uppercase that look like Latin uppercase
  'А':'A', 'В':'B', 'С':'C', 'Е':'E', 'Н':'H', 'К':'K',
  'М':'M', 'О':'O', 'Р':'P', 'Т':'T',
  // Cyrillic lowercase
  'а':'a', 'с':'c', 'е':'e', 'о':'o', 'р':'p',
};
const HOMOGLYPH_RE = new RegExp('[' + Object.keys(HOMOGLYPH_MAP).join('') + ']', 'g');
const ZERO_WIDTH_RE = new RegExp(
  '[' + [0x200B, 0x200C, 0x200D, 0x2060, 0xFEFF].map(c => String.fromCharCode(c)).join('') + ']',
  'g',
);

function normalize(input) {
  return input
    .normalize('NFKC')
    .replace(ZERO_WIDTH_RE, '')
    .replace(HOMOGLYPH_RE, ch => HOMOGLYPH_MAP[ch] ?? ch);
}

function classifyPart(part) {
  if (part === '(') return { type: 'syllable_open' };
  if (part === ')') return { type: 'syllable_close' };
  if (part in PAUSE_MS) return { type: 'pause', ms: PAUSE_MS[part], char: part };
  if (part === '!' || part === "'") return { type: 'stress_mark' };

  const bankSwitch = part.match(/^\[bank=([A-Za-z0-9_.\-]+)\]$/);
  if (bankSwitch) return { type: 'bank_switch', name: bankSwitch[1] };
  if (part === '[bank]') return { type: 'bank_reset' };
  if (part === '[glideTo]') return { type: 'directive', key: 'glideTo', valueStr: 'full' };

  const bracket = part.match(/^\[(\w+)=(-?\d+(?:\.\d+)?)\]$/);
  if (bracket) {
    return { type: 'directive', key: bracket[1], value: Number(bracket[2]), relative: false };
  }

  // Multiplicative bracket form, e.g. [gain*2] / [gain*0.5]. Distinct from
  // the additive +/- relative form compact letters use -- multiplying by X
  // then later by 1/X undoes it exactly regardless of the current value,
  // which is what a temporary "louder/quieter" span needs without knowing
  // what baseline it's layering on top of.
  const bracketMult = part.match(/^\[(\w+)\*(-?\d+(?:\.\d+)?)\]$/);
  if (bracketMult) {
    return { type: 'directive', key: bracketMult[1], value: Number(bracketMult[2]), relative: 'mult' };
  }

  // String-valued directives, e.g. [contour=rise] or [stressMode=classic].
  // Kept separate from the numeric form above (which is tried first, so a
  // numeric-looking value like "[rate=110]" is never misread as a string).
  const bracketStr = part.match(/^\[(\w+)=([A-Za-z][A-Za-z0-9_-]*)\]$/);
  if (bracketStr) {
    return { type: 'directive', key: bracketStr[1], valueStr: bracketStr[2], relative: false };
  }

  const noteForm = part.match(/^(b)(=)?([A-G][b#]?-?\d+)$/);
  if (noteForm) {
    const hz = noteToHz(noteForm[3]);
    if (hz != null) return { type: 'directive', key: 'base', value: hz, relative: false };
  }

  const compact = part.match(/^([a-z])(?:(=)?(([+-])?\d+(?:\.\d+)?))?$/);
  if (compact) {
    const [, letter, eq, full, sign] = compact;
    const keyMap = {
      b: 'base', r: 'rate', p: 'pause', s: 'scale',
      v: 'vibrato', w: 'vibratoRate',
      m: 'tremolo', n: 'tremoloRate',
      h: 'aspiration', t: 'tilt', g: 'effort',
    };
    const key = keyMap[letter];
    if (key) {
      if (full === undefined) {
        // Bare letter reset to initial value, drop bare `p`
        if (key !== 'pause') return { type: 'directive', key, reset: true };
        return null;
      }
      const value = Number(full);
      const relative = !eq && (sign === '+' || sign === '-');
      return { type: 'directive', key, value, relative };
    }
  }

  const phoneme = part.match(/^([A-Z]+)(['!])?(?:\(([+-]\d+(?:\.\d+)?)\)|([+-]\d+(?:\.\d+)?))?$/);
  if (phoneme) {
    const transientDelta = phoneme[3] !== undefined ? Number(phoneme[3]) : null;
    const stickyDelta = phoneme[4] !== undefined ? Number(phoneme[4]) : null;
    return {
      type: 'phoneme',
      code: phoneme[1],
      stressed: phoneme[2] !== undefined,
      pitchDelta: transientDelta ?? stickyDelta ?? 0,
      transient: transientDelta !== null,
    };
  }

  return { type: 'unknown', text: part };
}

export function tokenize(rawInput) {
  const source = normalize(rawInput);
  const len = source.length;
  const tokens = [];
  let i = 0;

  const findBlockEnd = (start) => {
    const end = source.indexOf('*/', start + 2);
    return end === -1 ? len : end + 2;
  };

  while (i < len) {
    const c = source[i];
    if (/\s/.test(c)) { i++; continue; }
    // Line comment: # only at boundary (start of input or after whitespace).
    if (c === '#' && (i === 0 || /\s/.test(source[i - 1]))) {
      while (i < len && source[i] !== '\n') i++;
      continue;
    }
    // Block comment
    if (c === '/' && source[i + 1] === '*') {
      i = findBlockEnd(i);
      continue;
    }

    const srcStart = i;
    let part = '';
    while (i < len && !/\s/.test(source[i])) {
      if (source[i] === '/' && source[i + 1] === '*') {
        i = findBlockEnd(i);
        continue;
      }
      part += source[i];
      i++;
    }
    const srcEnd = i;
    if (!part) continue;

    const tok = classifyPart(part);
    if (!tok) continue;
    tok.srcStart = srcStart;
    tok.srcEnd = srcEnd;

    if (tok.type === 'stress_mark') {
      for (let j = tokens.length - 1; j >= 0; j--) {
        if (tokens[j].type === 'phoneme') { tokens[j].stressed = true; break; }
      }
      continue;
    }
    tokens.push(tok);
  }

  return { tokens, source };
}

// Shapes a contour across one span of phoneme tokens (a sentence, or -- for
// 'alternate' mode -- smaller word-groups within it) and writes each
// phoneme's offset into `deltas`. Offsets are pure ADDITIVE shaping applied
// on top of whatever f0 the phoneme would already have (stress lift, manual
// pitch directives, tone diacritics, ...) -- they never touch the running
// `f0` itself, so contour and manual pitch control never fight each other.
function shapeSpan(phonemeTokens, direction, range, deltas) {
  const n = phonemeTokens.length;
  if (!n) return;
  for (let i = 0; i < n; i++) {
    const frac = n === 1 ? 0.5 : i / (n - 1);
    let v;
    switch (direction) {
      case 'rise':     v = range * (frac - 0.5); break;
      case 'fall':     v = range * (0.5 - frac); break;
      case 'risefall': v = (range / 2) * (1 - Math.abs(frac * 2 - 1)); break;
      case 'fallrise': v = -(range / 2) * (1 - Math.abs(frac * 2 - 1)); break;
      default:          v = 0;
    }
    deltas.set(phonemeTokens[i], v);
  }
}

// Pre-pass over the full token stream (run BEFORE the main render loop)
// that figures out, for every phoneme token, how much a sentence-level
// intonation contour should shift its pitch. Needs a lookahead because
// "rise toward the end of the sentence" requires knowing where the
// sentence ends -- something the single-pass render loop below doesn't
// know ahead of time.
//
// Sentence boundaries are '.' pauses (or end of input); ',' and ';' are
// treated as word-group boundaries, used only by 'alternate' mode to
// decide where one group's tone direction hands off to the next.
function computeContourDeltas(tokens, { mode: initialMode, range: initialRange, groupWords: initialGroupWords }) {
  const deltas = new Map();
  let mode = initialMode;
  let range = initialRange;
  let groupWords = initialGroupWords;
  let sentence = []; // mix of phoneme tokens and pause tokens, in order

  const flushSentence = () => {
    if (!sentence.length) return;
    const phonemeTokens = sentence.filter(t => t.type === 'phoneme');
    if (mode === 'alternate') {
      // Split into word-runs (phonemes between any pause), then group
      // every `groupWords` runs together and alternate direction per group.
      const wordRuns = [];
      let run = [];
      for (const t of sentence) {
        if (t.type === 'phoneme') run.push(t);
        else if (run.length) { wordRuns.push(run); run = []; }
      }
      if (run.length) wordRuns.push(run);
      for (let g = 0; g * groupWords < wordRuns.length; g++) {
        const group = wordRuns.slice(g * groupWords, (g + 1) * groupWords).flat();
        shapeSpan(group, g % 2 === 0 ? 'rise' : 'fall', range, deltas);
      }
    } else if (mode !== 'flat' && mode !== 'none') {
      shapeSpan(phonemeTokens, mode, range, deltas);
    }
    sentence = [];
  };

  for (const t of tokens) {
    if (t.type === 'directive') {
      if (t.key === 'contour' && t.valueStr && t.valueStr !== mode) {
        // Mode changed mid-sentence: shape what's accumulated so far under
        // the OLD mode as its own local span, then start fresh so the new
        // mode only shapes what comes after it.
        flushSentence();
        mode = t.valueStr;
      } else if (t.key === 'contourRange' && typeof t.value === 'number') {
        range = t.value;
      } else if (t.key === 'contourGroupWords' && typeof t.value === 'number') {
        groupWords = Math.max(1, Math.round(t.value));
      }
      continue;
    }
    if (t.type === 'phoneme') { sentence.push(t); continue; }
    if (t.type === 'pause') {
      sentence.push(t);
      if (t.char === '.') flushSentence();
      continue;
    }
  }
  flushSentence(); // trailing sentence with no closing "."

  return deltas;
}

// Extracts the subset of a target phoneme's fields that an inline
// "AA [glideTo=TYPE] OO" directive should glide toward:
//  - 'frequencies': just F1/F2/F3 -- glide the formant frequencies only,
//    leaving bandwidths/amplitudes/everything else as the source phoneme's.
//  - 'formants': F1-3 + BW1-3 -- frequencies and bandwidths.
//  - 'full' (default): every field the target phoneme defines, same as a
//    bank-authored static glideTo would.
function extractGlideFields(targetP, type) {
  if (type === 'frequencies') {
    const { F1, F2, F3 } = targetP;
    return { F1, F2, F3 };
  }
  if (type === 'formants') {
    const { F1, F2, F3, BW1, BW2, BW3 } = targetP;
    return { F1, F2, F3, BW1, BW2, BW3 };
  }
  return { ...targetP };
}

// Collapses an inline "PHONEME [glideTo] PHONEME" sequence into a single
// phoneme token that glides toward the second phoneme's parameters, instead
// of requiring a bank author to predefine a diphthong-like phoneme with its
// own static `glideTo`. The second phoneme is consumed as the glide TARGET
// only -- it's never separately rendered/heard, exactly like a bank-defined
// diphthong's endpoint isn't its own audible segment.
function applyGlideDirectives(tokens) {
  const out = [];
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    const next = tokens[i + 1];
    const after = tokens[i + 2];
    if (
      t.type === 'phoneme' &&
      next && next.type === 'directive' && next.key === 'glideTo' &&
      after && after.type === 'phoneme'
    ) {
      out.push({ ...t, glideToCode: after.code, glideToType: next.valueStr || 'full' });
      i += 2; // consume the directive and the target phoneme too
      continue;
    }
    out.push(t);
  }
  return out;
}

// Resolves paired [pitchStart=CODE]/[pitchTarget=CODE] tags (from the
// advanced prosody tag system) into an ABSOLUTE per-phoneme f0 override for
// every phoneme in the span between them. This has to live here rather
// than being precomputed by the caller because it needs the actual f0
// value AT the start position -- which depends on everything before it
// (directives, sticky pitch deltas) -- and only compile() tracks that.
// The lightweight simulation below re-derives f0's organic progression
// through the token stream (base/pitch directives, [semitone=N] shifts,
// and phonemes' own sticky pitchDelta) WITHOUT actually rendering anything,
// just to know "what would f0 be right before token X".
// Known simplification: if a later trajectory's start falls inside an
// earlier trajectory's own span, the pre-scan uses the ORGANIC (untagged)
// f0 progression rather than the earlier trajectory's overridden values --
// overlapping/nested trajectories are approximate, not exact.
function computePitchTrajectories(tokens, opts, warnings) {
  const overrides = new Map(); // phoneme token -> { startF0, endF0 }
  const initialBaseF0 = opts.baseF0 ?? DEFAULTS.baseF0;

  let f0 = initialBaseF0;
  const f0Before = new Map();
  for (const t of tokens) {
    f0Before.set(t, f0);
    if (t.type === 'directive') {
      if (t.key === 'base' || t.key === 'pitch') {
        if (t.reset) f0 = initialBaseF0;
        else if (t.relative) f0 += t.value;
        else if (typeof t.value === 'number') f0 = t.value;
      } else if (t.key === 'semitone' && typeof t.value === 'number') {
        f0 *= Math.pow(2, t.value / 12);
      }
    } else if (t.type === 'phoneme') {
      if (!t.transient) f0 += t.pitchDelta;
    }
  }

  const starts = [];
  const targets = new Map();
  let pendingStart = null, pendingTarget = null;
  for (const t of tokens) {
    if (t.type === 'directive') {
      if (t.key === 'pitchStart' && t.valueStr) pendingStart = { code: t.valueStr, mode: 'continuous' };
      else if (t.key === 'pitchStartMode' && t.valueStr && pendingStart) pendingStart.mode = t.valueStr;
      else if (t.key === 'pitchTarget' && t.valueStr) pendingTarget = { code: t.valueStr, mode: 'frequency', value: null };
      else if (t.key === 'pitchTargetMode' && t.valueStr && pendingTarget) pendingTarget.mode = t.valueStr;
      else if (t.key === 'pitchTargetValue' && typeof t.value === 'number' && pendingTarget) pendingTarget.value = t.value;
      else if (t.key === 'pitchTargetNote' && t.valueStr && pendingTarget) pendingTarget.value = t.valueStr;
      continue;
    }
    if (t.type === 'phoneme') {
      if (pendingStart) { starts.push({ ...pendingStart, afterToken: t }); pendingStart = null; }
      if (pendingTarget) { targets.set(pendingTarget.code, { ...pendingTarget, afterToken: t }); pendingTarget = null; }
    }
  }

  const phonemeTokens = tokens.filter(t => t.type === 'phoneme');
  const indexOf = new Map(phonemeTokens.map((t, i) => [t, i]));

  for (const start of starts) {
    const target = targets.get(start.code);
    if (!target) { warnings.push(`pitchStart references unknown or missing target tag "${start.code}"`); continue; }
    const startIdx = indexOf.get(start.afterToken);
    const targetIdx = indexOf.get(target.afterToken);
    if (startIdx == null || targetIdx == null || targetIdx < startIdx) {
      warnings.push(`pitchStart/pitchTarget pair "${start.code}" has an invalid span (target must come at or after start)`);
      continue;
    }
    const startF0 = f0Before.get(start.afterToken);
    let targetF0;
    if (target.mode === 'frequency') targetF0 = target.value ?? startF0;
    else if (target.mode === 'note') targetF0 = noteToHz(target.value) ?? startF0;
    else if (target.mode === 'semitone') targetF0 = startF0 * Math.pow(2, (target.value ?? 0) / 12);
    else targetF0 = startF0;

    const span = phonemeTokens.slice(startIdx, targetIdx + 1);
    const n = span.length;
    const lerp = (a, b, f) => a + (b - a) * f;
    for (let i = 0; i < n; i++) {
      if (start.mode === 'step') {
        const level = lerp(startF0, targetF0, n === 1 ? 1 : i / (n - 1));
        overrides.set(span[i], { startF0: level, endF0: level });
      } else {
        const frac0 = n === 1 ? 0 : i / n, frac1 = n === 1 ? 1 : (i + 1) / n;
        overrides.set(span[i], { startF0: lerp(startF0, targetF0, frac0), endF0: lerp(startF0, targetF0, frac1) });
      }
    }
  }
  return overrides;
}

export function compile(parsed, opts = {}) {
  // accept { tokens, source } shape from tokenize()
  // fallback to legacy otherwise
  let tokens = Array.isArray(parsed) ? parsed : parsed.tokens;
  tokens = applyGlideDirectives(tokens);
  const source = Array.isArray(parsed) ? '' : (parsed.source ?? '');
  const initialBaseF0      = opts.baseF0 ?? DEFAULTS.baseF0;
  const initialRate        = opts.rate ?? DEFAULTS.rate;
  const initialScale       = opts.scale ?? 1.0;
  const initialVibrato     = opts.vibratoDepth ?? 0;
  const initialVibratoRate = opts.vibratoRate ?? 5;
  const initialTremolo     = opts.tremoloDepth ?? 0;
  const initialTremoloRate = opts.tremoloRate ?? 5;
  const initialAspiration  = opts.aspiration ?? 0;
  const initialTilt        = opts.tilt ?? 0;
  const initialEffort      = opts.effort ?? 0.5;
  const initialGain        = opts.gain ?? 3.5; // matches synth-core.js's own default so untouched content is unaffected
  const registry           = opts.registry ?? banks;
  // Overall pacing multiplier: 2 = twice as fast, 0.5 = half speed.
  // Applied as a final pass over the computed schedule (below) rather than
  // threaded through `rate`, because individual tokens/segments can set
  // their own absolute rate (e.g. "r100", "r150") that would otherwise
  // ignore a base-rate change. This only rescales WHEN events happen
  // (atMs) -- how long phonemes are held, how much gap sits between them.
  // It deliberately does NOT touch transitionMs (see `glideSpeed` below):
  // a person talking faster holds vowels for less time and leaves shorter
  // pauses, but their articulators don't physically move through a glide
  // any quicker, so formant transitions/diphthong glides keep their
  // natural duration regardless of overall pace.
  const speed = opts.speed > 0 ? opts.speed : 1;
  // Separate, independent control over how fast the articulators move
  // through transitions/glides themselves (formant ramps, diphthong
  // glides, stop bursts). Kept apart from `speed` on purpose -- see above.
  const glideSpeed = opts.glideSpeed > 0 ? opts.glideSpeed : 1;
  // Sentence-level intonation shaping: 'flat' (default, no change), 'rise',
  // 'fall', 'risefall', 'fallrise', or 'alternate' (every `contourGroupWords`
  // words swaps direction). Can also be switched mid-string with
  // [contour=NAME] / [contourRange=N] / [contourGroupWords=N].
  let stressMode = opts.stressMode ?? 'classic';
  const contourDeltas = computeContourDeltas(tokens, {
    mode: opts.contour ?? 'flat',
    range: opts.contourRange ?? 30,
    groupWords: opts.contourGroupWords ?? 2,
  });
  const initialPhonemes    = resolveBank(opts.bank, registry).phonemes;
  let phonemes             = initialPhonemes;
  let f0           = initialBaseF0;
  let rate         = initialRate;
  let scale        = initialScale;
  let vibrato      = initialVibrato;
  let vibratoRate  = initialVibratoRate;
  let tremolo      = initialTremolo;
  let tremoloRate  = initialTremoloRate;
  let aspiration   = initialAspiration;
  let tilt         = initialTilt;
  let effort       = initialEffort;
  let gain         = initialGain;
  // Region-local speed multiplier, set/reset via [localSpeed=N]. Unlike
  // `speed` above (a single global pass over the finished schedule), this
  // lives INSIDE the render loop and divides duration as tokens are
  // rendered -- so it composes with (amplifies) whatever the Pace slider
  // is already doing, rather than overriding it. A [{allegro ... allegro}]
  // span at localSpeed=1.4 on top of a 1.5x Pace setting plays back at
  // 1.4*1.5 = 2.1x, not a flat 1.4x.
  let localSpeedMult = opts.localSpeed > 0 ? opts.localSpeed : 1;
  // Bare `b` / `r` / `s` / `v` / `h` / `t` / `g` reset to opts values
  const schedule = [];
  const warnings = [];
  // Resolves [pitchStart=CODE]/[pitchTarget=CODE] tag pairs into an
  // absolute per-phoneme f0 override (see computePitchTrajectories above).
  const pitchOverrides = computePitchTrajectories(tokens, opts, warnings);
  const phrases = [];
  let timeMs = 0;
  // phrase covers [phraseSrcStart .. token.srcEnd) of source and time
  // [phraseTimeStart .. timeMs] when the next sound finishes
  let phraseSrcStart = 0;
  let phraseTimeStart = 0;
  const emitPhrase = (t) => {
    phrases.push({
      srcStart: phraseSrcStart,
      srcEnd: t.srcEnd,
      // the audible token
      tokenSrcStart: t.srcStart,
      tStartMs: phraseTimeStart,
      tEndMs: timeMs,
      kind: t.type,
      phoneme: t.type === 'phoneme' ? t.code : null,
    });
    phraseSrcStart = t.srcEnd;
    phraseTimeStart = timeMs;
  };

  // Apply the running formant scale to a phoneme parameter set.
  // `glideTo` overrides the formant fields for diphthong endpoints
  const scaled = (p, f0Hz, glideTo = null) => {
    const src = glideTo ? { ...p, ...glideTo } : p;
    return {
      ...p, ...glideTo,
      F0: f0Hz,
      F1: src.F1 * scale, F2: src.F2 * scale, F3: src.F3 * scale,
      BW1: src.BW1 * scale, BW2: src.BW2 * scale, BW3: src.BW3 * scale,
    };
  };

  const renderPhoneme = (t, slotMs) => {
    const p = phonemes[t.code];
    if (!p) {
      warnings.push(`unknown phoneme: ${t.code}`);
      return 0;
    }
    const usePitchStress = t.stressed && (stressMode === 'classic' || stressMode === 'pitch' || stressMode === 'all');
    const useEffortStress = t.stressed && (stressMode === 'effort' || stressMode === 'all');
    const contourOffset = contourDeltas.get(t) ?? 0;
    const pitchOverride = pitchOverrides.get(t);
    // A pitch-trajectory tag (advanced prosody system) is the FULL
    // authority over f0 for its span -- it bypasses stress lift and
    // contour shaping for that phoneme rather than stacking with them,
    // since the whole point of tagging a span is explicit manual control.
    const startF0 = pitchOverride ? pitchOverride.startF0
      : (usePitchStress ? f0 + DEFAULTS.stressF0Lift : f0) + contourOffset;
    const endF0 = pitchOverride ? pitchOverride.endF0 : startF0 + t.pitchDelta;
    const prevEffort = effort;
    if (useEffortStress) effort = Math.min(1, effort + 0.25);
    // An inline "AA [glideTo] OO" directive (see applyGlideDirectives above)
    // takes precedence over a bank-authored static p.glideTo, the same way
    // hand-specifying it would.
    let glideTo = p.glideTo || null;
    if (t.glideToCode) {
      const targetP = phonemes[t.glideToCode];
      if (!targetP) {
        warnings.push(`unknown glideTo phoneme: ${t.glideToCode}`);
      } else {
        glideTo = extractGlideFields(targetP, t.glideToType);
      }
    }
    let result;
    if (p.isStop) {
      const burstMs = Math.min(DEFAULTS.stopBurstMs, slotMs * 0.3);
      const silenceMs = slotMs - burstMs;
      silence(Math.min(20, silenceMs * 0.4));
      timeMs += silenceMs;
      emit(scaled(p, startF0), Math.min(5, burstMs * 0.2));
      timeMs += burstMs;
      result = slotMs;
    } else if (glideTo) {
      // Emphasis stays on the FIRST sound (nucleus): hold it for most of
      // the slot, then glide toward the second sound only near the very
      // end, with just a brief moment actually at the target -- like a
      // real diphthong, not a 50/50 cross-fade.
      const onset = slotMs * 0.65, glide = slotMs * 0.30, offset = slotMs * 0.05;
      emit(scaled(p, startF0), Math.min(20, onset));
      timeMs += onset;
      emit(scaled(p, endF0, glideTo), glide);
      timeMs += glide + offset;
      result = slotMs;
    } else if (t.pitchDelta !== 0) {
      emit(scaled(p, startF0), Math.min(25, slotMs * 0.25));
      timeMs += slotMs * 0.25;
      emit(scaled(p, endF0), slotMs * 0.6);
      timeMs += slotMs * 0.75;
      result = slotMs;
    } else {
      const trans = Math.min(DEFAULTS.defaultTransitionMs, slotMs * 0.4);
      emit(scaled(p, startF0), trans);
      timeMs += slotMs;
      result = slotMs;
    }
    effort = prevEffort;
    return result;
  };

  let inSyllable = false;
  let syllableQueue = [];
  const flushSyllable = () => {
    if (!syllableQueue.length) { inSyllable = false; return; }
    const slot = rate / syllableQueue.length / localSpeedMult;
    for (const t of syllableQueue) {
      renderPhoneme(t, slot);
      emitPhrase(t);
      const ov = pitchOverrides.get(t);
      if (ov) f0 = ov.endF0;
      else if (!t.transient) f0 += t.pitchDelta;
    }
    syllableQueue = [];
    inSyllable = false;
  };

  const stateExtras = () => ({
    vibratoDepth: vibrato,
    vibratoRate,
    tremoloDepth: tremolo,
    tremoloRate,
    aspiration,
    tilt,
    effort,
    gain,
  });

  const emit = (target, transitionMs) => {
    schedule.push({
      atMs: timeMs,
      target: { ...target, ...stateExtras() },
      transitionMs,
    });
  };
  // Zero every formant amplitude and every anti-formant's depth, not just
  // A1-A3 -- otherwise a phoneme/directive that ever turns on A4..A9 or
  // AA1..AA3 leaves them ringing straight through pauses and the final
  // fade-out, since setTarget only updates keys present in the payload.
  const silenceTarget = {};
  for (let n = 1; n <= MAX_FORMANTS; n++) silenceTarget[`A${n}`] = 0;
  for (let n = 1; n <= MAX_ANTIFORMANTS; n++) silenceTarget[`AA${n}`] = 0;
  const silence = (transitionMs = 30) => emit(silenceTarget, transitionMs);

  for (const t of tokens) {
    if (t.type === 'unknown') {
      warnings.push(`unknown token: ${t.text}`);
      continue;
    }

    if (t.type === 'bank_switch') {
      const target = registry.get(t.name);
      if (!target) {
        warnings.push(`unknown bank: ${t.name}`);
        continue;
      }
      phonemes = target.phonemes;
      continue;
    }
    if (t.type === 'bank_reset') {
      phonemes = initialPhonemes;
      continue;
    }

    if (t.type === 'syllable_open') {
      if (inSyllable) {
        warnings.push('nested ( ignored');
        continue;
      }
      inSyllable = true;
      syllableQueue = [];
      continue;
    }
    if (t.type === 'syllable_close') {
      if (!inSyllable) {
        warnings.push('unmatched )');
        continue;
      }
      flushSyllable();
      continue;
    }

    if (t.type === 'directive') {
      switch (t.key) {
        case 'base':
        case 'pitch':
          if (t.reset) f0 = initialBaseF0;
          else if (t.relative) f0 += t.value;
          else f0 = t.value;
          break;
        case 'rate':
          if (t.reset) rate = initialRate;
          else if (t.relative) rate += t.value;
          else rate = t.value;
          break;
        case 'scale':
          if (t.reset) scale = initialScale;
          else if (t.relative) scale += t.value;
          else scale = t.value;
          break;
        case 'vibrato':
          if (t.reset) vibrato = initialVibrato;
          else if (t.relative) vibrato += t.value;
          else vibrato = t.value;
          break;
        case 'vibratoRate':
          if (t.reset) vibratoRate = initialVibratoRate;
          else if (t.relative) vibratoRate += t.value;
          else vibratoRate = t.value;
          break;
        case 'tremolo':
          if (t.reset) tremolo = initialTremolo;
          else if (t.relative) tremolo += t.value;
          else tremolo = t.value;
          break;
        case 'tremoloRate':
          if (t.reset) tremoloRate = initialTremoloRate;
          else if (t.relative) tremoloRate += t.value;
          else tremoloRate = t.value;
          break;
        case 'aspiration':
          if (t.reset) aspiration = initialAspiration;
          else if (t.relative) aspiration += t.value;
          else aspiration = t.value;
          break;
        case 'tilt':
          if (t.reset) tilt = initialTilt;
          else if (t.relative) tilt += t.value;
          else tilt = t.value;
          break;
        case 'effort':
          if (t.reset) effort = initialEffort;
          else if (t.relative) effort += t.value;
          else effort = t.value;
          break;
        case 'gain':
          if (t.reset) gain = initialGain;
          else if (t.relative === 'mult') gain *= t.value;
          else if (t.relative) gain += t.value;
          else gain = t.value;
          break;
        case 'localSpeed':
          if (t.reset) localSpeedMult = 1;
          else if (t.relative === 'mult') localSpeedMult *= t.value;
          else if (t.relative) localSpeedMult += t.value;
          else localSpeedMult = t.value > 0 ? t.value : 1;
          break;
        case 'pause':
          silence();
          timeMs += Math.abs(t.value) / localSpeedMult;
          emitPhrase(t);
          break;
        case 'stressMode':
          if (t.valueStr) stressMode = t.valueStr;
          break;
        case 'contour':
        case 'contourRange':
        case 'contourGroupWords':
          // Already consumed by the computeContourDeltas() pre-pass above;
          // nothing to do at render time.
          break;
        case 'semitone':
          // Multiplicative pitch shift from CURRENT f0 -- N semitones is a
          // frequency ratio of 2^(N/12), not an additive Hz amount, so this
          // is deliberately its own case rather than reusing 'base'/'pitch'.
          if (typeof t.value === 'number') f0 *= Math.pow(2, t.value / 12);
          break;
        case 'pitchStart':
        case 'pitchStartMode':
        case 'pitchTarget':
        case 'pitchTargetMode':
        case 'pitchTargetValue':
        case 'pitchTargetNote':
          // Already consumed by the computePitchTrajectories() pre-pass
          // above; nothing to do at render time.
          break;
        case 'glideTo':
          // A well-formed "PHONEME [glideTo] PHONEME" never reaches here --
          // applyGlideDirectives() consumes it before the main loop runs.
          // Reaching this means it wasn't sandwiched between two phonemes.
          warnings.push('[glideTo] must directly follow a phoneme and be directly followed by another phoneme');
          break;
        default:
          warnings.push(`unknown directive: ${t.key}`);
      }
      continue;
    }

    if (t.type === 'pause') {
      silence();
      timeMs += t.ms / localSpeedMult;
      emitPhrase(t);
      continue;
    }

    // phoneme: defer to the group buffer if inside (...), otherwise render
    // straight to the schedule
    if (inSyllable) {
      syllableQueue.push(t);
      continue;
    }

    const useDurationStress = t.stressed && (stressMode === 'classic' || stressMode === 'duration' || stressMode === 'all');
    const phoneRate = (useDurationStress ? rate * DEFAULTS.stressDurationFactor : rate) / localSpeedMult;
    renderPhoneme(t, phoneRate);
    emitPhrase(t);

    const pitchOv = pitchOverrides.get(t);
    if (pitchOv) f0 = pitchOv.endF0;
    else if (!t.transient) f0 += t.pitchDelta;
  }

  if (inSyllable) {
    warnings.push('unclosed (');
    flushSyllable();
  }

  timeMs += DEFAULTS.sentenceFinalHoldMs;
  silence(DEFAULTS.fadeOutMs);
  timeMs += DEFAULTS.trailOffMs;

  // Hold the final phrase highlighted
  if (phrases.length) phrases[phrases.length - 1].tEndMs = timeMs;

  if (speed !== 1) {
    for (const e of schedule) {
      e.atMs /= speed;
    }
    for (const p of phrases) {
      p.tStartMs /= speed;
      p.tEndMs /= speed;
    }
    timeMs /= speed;
  }
  if (glideSpeed !== 1) {
    for (const e of schedule) {
      e.transitionMs /= glideSpeed;
    }
  }

  return { schedule, totalMs: timeMs, warnings, phrases, source };
}

export function compileString(input, opts) {
  return compile(tokenize(input), opts);
}